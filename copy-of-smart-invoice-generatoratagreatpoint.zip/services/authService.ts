// This file is deprecated and has been replaced by `services/apiService.ts`.
// All authentication logic has been moved to the new unified service.
// This file can be safely deleted from your project.

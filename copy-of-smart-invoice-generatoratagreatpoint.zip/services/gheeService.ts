// This file is deprecated and has been replaced by `services/apiService.ts`.
// All company and invoice logic has been moved to the new unified service.
// This file can be safely deleted from your project.
